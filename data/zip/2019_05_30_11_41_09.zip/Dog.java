package chapter05.exercise_number_seven;

public class Dog {
	private String breed;
	private int age;
	private String color;
	
	public Dog() {
		breed = null;
		age = 0;
		color = null;
	}
	
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public void setAge(int age) {
		this.age= age;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public String getBreed() {
		return breed;
	}
	public int getAge() {
		return age;
	}
	public String getColor() {
		return color;
	}
	
	public String barking() {
		return "�۸�";
	}
	public String hungry() {
		return "����Ŀ�";
	}
	public String sleeping() {
		return "�ǵ�������...�ڴ����̿���...";
	}

	@Override
	public String toString() {
		return "Dog [breed=" + breed + ", age=" + age + ", color=" + color + "]";
	}
}
